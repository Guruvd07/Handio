const mongoose = require("mongoose");

const providerProfileSchema = new mongoose.Schema({

  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  category: String,
  city: String,
  area: String,
  description: String,

  verified: {
    type: Boolean,
    default: false
  },

  averageRating: {
    type: Number,
    default: 0
  },

  totalReviews: {
    type: Number,
    default: 0
  }

}, { timestamps: true });

module.exports = mongoose.model("ProviderProfile", providerProfileSchema);
