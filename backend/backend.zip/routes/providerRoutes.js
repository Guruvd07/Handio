const express = require("express");

const Provider = require("../models/ProviderProfile");
const Booking = require("../models/Booking");

const auth = require("../middlewares/authMiddleware");
const role = require("../middlewares/roleMiddleware");

const { createProfile } = require("../controllers/providerController");

const router = express.Router();


/* =========================
   CREATE PROVIDER PROFILE
========================= */

router.post(
  "/profile",
  auth,
  role("provider"),
  createProfile
);


/* =========================
   GET FILTER OPTIONS  ✅ before /:id
========================= */

router.get("/filters/options", async (req, res) => {
  try {
    const categories = await Provider.distinct("category", { verified: true });
    const cities = await Provider.distinct("city", { verified: true });
    const areas = await Provider.distinct("area", { verified: true });

    res.json({ categories, cities, areas });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


/* =========================
   GET MY PROFILE (provider)
========================= */

router.get(
  "/me/profile",
  auth,
  role("provider"),
  async (req, res) => {
    try {
      const profile = await Provider.findOne({
        userId: req.user.id
      }).populate("userId", "name email");

      res.json(profile);

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
);


/* =========================
   GET MY BOOKING REQUESTS  ✅ FIX FOR DASHBOARD
========================= */

router.get(
  "/me/bookings",
  auth,
  role("provider"),
  async (req, res) => {
    try {
      // find provider profile first
      const profile = await Provider.findOne({
        userId: req.user.id
      });

      if (!profile) {
        return res.status(404).json({ msg: "Provider profile not found" });
      }

      // use profile._id — NOT user id
      const bookings = await Booking.find({
        providerId: profile._id
      })
        .populate("customerId", "name email")
        .sort({ createdAt: -1 });

      res.json(bookings);

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
);


/* =========================
   SEARCH PROVIDERS
========================= */

router.get("/", async (req, res) => {
  try {
    const { category, city, area } = req.query;

    const filter = { verified: true };

    if (category) filter.category = category;
    if (city) filter.city = city;
    if (area) filter.area = area;

    const providers = await Provider.find(filter)
      .populate("userId", "name email")
      .sort({ createdAt: -1 });

    res.json(providers);

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


/* =========================
   GET PROVIDER BY ID  ✅ LAST
========================= */

router.get("/:id", async (req, res) => {
  try {
    const provider = await Provider.findById(req.params.id)
      .populate("userId", "name email");

    if (!provider)
      return res.status(404).json({ msg: "Provider not found" });

    res.json(provider);

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


module.exports = router;
