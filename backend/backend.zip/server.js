const express = require("express");
const cors = require("cors");
require("dotenv").config();

const connectDB = require("./config/db");

/* ROUTE IMPORTS — CORRECT */
const providerRoutes = require("./routes/providerRoutes");
const authRoutes = require("./routes/authRoutes");
const adminRoutes = require("./routes/adminRoutes");
const bookingRoutes = require("./routes/bookingRoutes");
const reviewRoutes = require("./routes/reviewRoutes");

const app = express();

app.use(cors());
app.use(express.json());

/* ROUTES */
app.use("/providers", providerRoutes);
app.use("/auth", authRoutes);
app.use("/admin", adminRoutes);
app.use("/bookings", bookingRoutes);
app.use("/api/reviews", reviewRoutes);

/* DB */
connectDB();

/* HEALTH */
app.get("/", (req, res) => {
  res.send("Backend Running");
});

/* SERVER */
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
